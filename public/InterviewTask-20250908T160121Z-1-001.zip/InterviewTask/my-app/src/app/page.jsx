import React from "react";
import Navbar from "./components/Navbar";
import Header from "./components/Header";
import Features from "./components/Features";
import Create from "./components/Create";
import Question from "./components/Question";
import Footer from "./components/Footer";




const page = () => {
  return (
    <div>
      <Navbar />
      <Header />
      <Features/>
      <Create/>
      <Question/>
      <Footer/>
    </div>
  );
};

export default page;
